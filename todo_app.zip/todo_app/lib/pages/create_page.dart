import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class CreatePage extends StatefulWidget {
  const CreatePage({Key? key}) : super(key: key);

  @override
  State<CreatePage> createState() => _CreatePageState();
}

class _CreatePageState extends State<CreatePage> {
  final _formKey = GlobalKey<FormState>();
  final temaCtl = TextEditingController();
  final tapshyrmaCtl = TextEditingController();
  final ubakytCtl = TextEditingController();
  DateTime? ubakyt;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Тапшырма кошуу'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                TextFormField(
                  controller: temaCtl,
                  decoration: const InputDecoration(
                    hintText: 'Тема',
                  ),
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: tapshyrmaCtl,
                  decoration: const InputDecoration(
                    hintText: 'Тапшырма жөнүндө маалымат',
                  ),
                ),
                const SizedBox(height: 20),
                TextFormField(
                  readOnly: true,
                  controller: ubakytCtl,
                  decoration: InputDecoration(
                    suffixIcon: const Icon(Icons.calendar_month),
                    hintText: ubakyt != null
                        ? DateFormat(
                            'd.MM.yyyy',
                          ).format(ubakyt!)
                        : 'Убакытты танда',
                  ),
                  onTap: () async {
                    ubakyt = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2101),
                    );
                    setState(() {});
                  },
                ),
                const SizedBox(height: 40),
                ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(200, 60),
                  ),
                  child: const Text(
                    'Сактоо',
                    style: TextStyle(fontSize: 20),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
