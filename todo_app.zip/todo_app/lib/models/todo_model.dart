class TodoModel {
  const TodoModel({
    required this.tema,
    required this.tapshyrma,
    required this.ubakyt,
  });

  final String tema;
  final String tapshyrma;
  final String ubakyt;

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'tema': tema,
      'tapshyrma': tapshyrma,
      'ubakyt': ubakyt,
    };
  }
}
